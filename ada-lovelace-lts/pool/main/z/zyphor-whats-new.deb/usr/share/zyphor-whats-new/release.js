const releaseNotes = {
    distro: "Zyphor OS Ada Lovelace LTS",
    version: "2.2.1-ada-lovelace-lts-u72",
    date: "Updated On: October 10, 2026 @ 07:47 AM",

    sections: [
        {
            "title": "GRUB OS Probing",
            "items": [
                "Automatically enables GRUB OS probing to detect other operating systems during boot",
                "Automatically regenerates the GRUB configuration after enabling OS probing"
            ]
        }
    ]
};