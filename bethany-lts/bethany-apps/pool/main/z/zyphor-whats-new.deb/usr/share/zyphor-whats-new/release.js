const releaseNotes = {
    distro: "Zyphor OS 3 \"Bethany\" LTS",
    version: "3.0.0-bethany-lts-u3",
    date: "Updated On: October 12, 2026 @ 01:50 PM",

    sections: [
        {
            "title": "Redesigned Zyphor Command Center",
            "items": [
                "Introduced a completely redesigned Zyphor Command Center with a modern dark look",
                "Added a new sidebar with the Zyphor logo, grouped sections (Account, System, Doctor, Packages), and a highlighted current page",
                "Every page now has a clear title and a short description of what it does",
                "Added a terminal-style output panel with easier-to-read text and a Clear button",
                "Added a progress animation while System Upgrade, System Clean, Doctor, and Package tasks are running",
                "Added clear ✔ Finished and ✖ Failed messages at the end of every task, so you always know how it went",
                "Task buttons are now disabled while a task is running to prevent starting the same task twice",
                "Pressing Enter in the Search, Install, and Uninstall boxes now starts the action",
                "Colored terminal codes are no longer shown as unreadable symbols in the output panel",
                "Command Center now opens faster, and each page loads only when you open it",
                "The Packages/Apps list now loads automatically the first time you open it",
                "User Management now starts its local service only when you open it",
                "If a page fails to open, an error message is shown instead of closing the whole app"
            ]
        },
        {
            "title": "Security & Reliability",
            "items": [
                "Improved the safety of the Search, Install, and Uninstall package boxes so typed text can no longer be run as system commands",
                "Package names that begin with a dash are now rejected as invalid input",
                "Improved how long task output is displayed, so lines no longer break in the wrong places"
            ]
        },
        {
            "title": "New Desktop Environment",
            "items": [
                "Introduced a refreshed Zyphor OS desktop environment with an updated visual experience",
                "Added a new default desktop layout with updated panel launchers and desktop shortcuts",
                "Added new default wallpapers and refreshed desktop artwork",
                "Updated the default application launcher for a cleaner and more accessible desktop experience",
                "Improved the default XFCE desktop configuration for new installations and newly created users",
                "Desktop environment updates can be applied through sudo zy system upgrade",
                "New desktop configurations are applied to newly created users through /etc/skel",
                "Existing users can keep their current desktop configuration until they deliberately apply the new desktop environment updates",
                "Desktop configuration updates are being tested in a virtual machine to help prevent existing user configurations from being overwritten or damaged"
            ]
        }
    ]
};